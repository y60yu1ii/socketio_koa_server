/*jshint esversion: 8 */
let channelToken = "8h05GEixlbJHC7dXt5LcB5wVfyEYwLYdJXULjpIBEIXo4mLJLL72NEaNFNEQ+x6mmR8HrKPnoi3TgQ0a2jCU53hkNZetb0ho8vIXOO9MtMbeYFYBhJKTIQ9pgSLDJfPy/pvYbzkBK33ylREAmP5D3AdB04t89/1O/w1cDnyilFU=";
let url = "https://api.line.me/v2/bot/message/reply";

module.exports.channelToken = channelToken;
module.exports.url = url;